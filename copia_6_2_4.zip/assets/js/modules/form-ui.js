//assets/js/modules/form-ui.js
"use strict";

/*
  - Gestión de UI del formulario: botones de limpiar, fechas, shimmer, etc.
*/

import { clearError, clearInfoMessage } from "./form-utils.js";
import { updateNextButtonState } from "./form-navigation.js";
import { debouncedUpdateSummary } from "./form-summary.js";
import { filtrarModalidades } from "./form-calculations.js";

/**
 * Muestra u oculta el botón de limpiar dentro de un contenedor de input
 */
function toggleClearButton(input) {
	const container = input.closest(".form__input-container");
	const clearBtn = container?.querySelector(".form__clear-btn");
	if (clearBtn) {
		clearBtn.style.display = input.value.trim() ? "flex" : "none";
	}
}

/**
 * Configura los listeners para todos los botones "clear" de campos
 */
function setupClearButtons() {
	document.addEventListener("click", (event) => {
		const clearBtn = event.target.closest(".form__clear-btn");
		if (!clearBtn) return;

		const input = clearBtn
			.closest(".form__input-container")
			?.querySelector(".form__input");

		if (input) {
			input.value = "";
			clearError(input);
			clearInfoMessage(input);
			input.dispatchEvent(new Event("input"));

                        updateNextButtonState();
                        debouncedUpdateSummary();
		}
	});

	document.querySelectorAll(".form__input").forEach((input) => {
		input.addEventListener("input", () => toggleClearButton(input));
	});
}

/**
 * Pone el valor y el mínimo de fecha de la garantía al día de hoy
 */
function setTodayForGarantia() {
        const fechaInput = document.getElementById("fecha_inicio_garantia");
        if (!fechaInput) return;

        const today = new Date().toISOString().split("T")[0];
        const autoFillEnabled = fechaInput.dataset.autoFill !== "0";

        fechaInput.min = today;
        if (autoFillEnabled && !fechaInput.value) {
                fechaInput.value = today;
        }

        updateNextButtonState();
        debouncedUpdateSummary();
}

/**
 * Abre el picker nativo al click y actualiza estado al cambio
 */
function handleDateInputs() {
        document.querySelectorAll('input[type="date"]').forEach((input) => {
                input.addEventListener("click", () => input.showPicker?.());
                input.addEventListener("change", () => {
                        updateNextButtonState();
                        debouncedUpdateSummary();
                });
        });
}

/**
 * Crea un párrafo de mensaje de info dentro de un contenedor dado
 */
function createInfoMessage(container) {
        const message = document.createElement("p");
        message.classList.add("form__info-message");
        container.appendChild(message);
        return message;
}

/**
 * Fuerza la desactivación del autocompletado del navegador en los campos sensibles
 * para evitar que Chrome muestre el diálogo de guardar dirección con datos de terceros.
 */
function disableAddressAutocomplete() {
        const form = document.getElementById("form-garantia");
        if (!form) return;

        form.autocomplete = "off";
        form.setAttribute("data-form-type", "other");
        form.setAttribute("name", `form-garantia-${Date.now().toString(36)}`);

        const sectionToken = `nostore-${Date.now().toString(36)}`;

        const fieldsToDisable = [
                "nombre_apellidos",
                "dni",
                "telefono",
                "correo",
                "direccion",
                "localidad",
                "provincia",
                "codigo_postal",
        ];

        fieldsToDisable.forEach((id) => {
                const input = document.getElementById(id);
                if (!input) return;
                const blocker = `${sectionToken}-${id}`;
                input.setAttribute("autocomplete", `section-${sectionToken} off`);
                input.setAttribute("name", blocker);
                input.setAttribute("data-form-type", "other");
                input.setAttribute("autocorrect", "off");
                input.setAttribute("autocapitalize", "off");
                input.setAttribute("spellcheck", "false");
        });
}

/**
 * Inicializador global del módulo de UI del formulario
 */
function init() {
        setupClearButtons();
        disableAddressAutocomplete();
        setTodayForGarantia();
        handleDateInputs();

	// Limpia error visual de vendedor si cambia selección
	const usuarioSelect = document.getElementById("usuario-rol");
	if (usuarioSelect) {
		usuarioSelect.addEventListener("change", () => {
                        clearError(usuarioSelect);
                        updateNextButtonState();
                        debouncedUpdateSummary();
                });
        }
	const canalSelect = document.getElementById("canal-venta");
	if (canalSelect) {
		canalSelect.addEventListener("change", () => {
                        clearError(canalSelect);
                        updateNextButtonState();
                        debouncedUpdateSummary();
                });
        }

}

export default {
        init,
        toggleClearButton,
        createInfoMessage,
};
